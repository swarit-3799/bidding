<?php
 include 'dbconn.php';

if(isset($_POST['active']))
 {
    $q = "UPDATE `products` SET `disable` = '0' WHERE `product_id` = '".$_POST['product_id']."' ";
  
    if(mysqli_query($dbconn,$q))
{
    header('Location:allproduct.php');
}
else
{
	echo "failedddddddd";
}
 }


?>