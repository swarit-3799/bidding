<?php
 include 'dbconn.php';
 //$product_id = $_GET['product_id'];

if(isset($_POST['winnerc']))
 {
    $q = "UPDATE `bid` SET `winner` = '0' WHERE `bid_id` = '".$_POST['bid_id']."' ";

    if(mysqli_query($dbconn,$q))
    {
      $q = "SELECT `bid_id`, `product_id`, `client_id`, `price`, `date`, `status`, `winner`, `orderp` FROM `bid` WHERE `bid_id`='".$_POST["bid_id"]."'";
      $r = mysqli_query($dbconn,$q);
      $client_id = 0;
      while ($ro = mysqli_fetch_assoc($r)) {
        $client_id = $ro["client_id"];
      }
      if($client_id != 0) {
        $q = "INSERT INTO `points`(`client_id`, `bid_id`, `points`, `type`, `date`) VALUES ('".$client_id."','".$_POST["bid_id"]."','50','2','".date('Y-m-d H:i:s')."')";
        if(mysqli_query($dbconn,$q)) {
          header('Location:allproduct.php');
        }
      }
    header('Location:allproduct.php');
}
else
{
	echo "failedddddddd";
}
 }


?>
