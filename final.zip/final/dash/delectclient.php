<?php
 include 'dbconn.php';

if(isset($_POST['delect']))
 {
    $q = "UPDATE `client` SET `status` = '0' WHERE `client_id` = '".$_POST['client_id']."'";
  
    if(mysqli_query($dbconn,$q))
    {
    header('Location:client_info.php');
}
else
{
	echo "failedddddddd";
}
 }


?>