<?php
 include 'dbconn.php';

if(isset($_POST['ban']))
 {
    $q = "UPDATE `products` SET `disable` = '1' WHERE `product_id` = '".$_POST['product_id']."' ";
  
    if(mysqli_query($dbconn,$q))
{
    header('Location:allproduct.php');
}
else
{
	echo "failedddddddd";
}
 }


?>