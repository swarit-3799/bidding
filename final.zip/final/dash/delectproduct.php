<?php

include('dbconn.php');
 if(isset($_POST['delect']))
 {
    $q = "DELETE FROM `products` WHERE `product_id` = '".$_POST['product_id']."'";
  
    if(mysqli_query($dbconn,$q))
    {
    header('Location:allproduct.php');
}
else
{
	echo "failedddddddd";
}
 }

 ?>