<?php
	
session_start();
include('dbconn.php');

if($_POST['export']=='F'){
	$query="SELECT * FROM `client` WHERE  `status` = '1' ";
	$filename="client_info.xls";
}





if (isset($query)) {
			
			header("Content-Type:application/vnd.ms-excel");
			header("Content-Disposition:attachement;filename=\"$filename\"");

			$ispheader=false;
			
				 include('dbconn.php');
				
				$result=mysqli_query($dbconn,$query);
				while ($row = $result->fetch_assoc()) {
					# code...
				
					if (! $ispheader) {
						echo implode("\t",array_keys($row))."\n";
						$ispheader=true;
						# code...
					}
					echo implode("\t",array_values($row))."\n";
				}
			
			exit();# code...
		}

?>