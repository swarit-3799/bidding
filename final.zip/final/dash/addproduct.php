
<?php
session_start();

   include('dbconn.php');
   if(isset($_SESSION['id']))
 {
date_default_timezone_set('Asia/Kolkata');
$date = date( 'Y-m-d H:i:s', time () );
   if(isset($_POST['add']))
{

   $title = $_POST['ptitle'];
   $desc = $_POST['pdesc'];
   $pprice = $_POST['pprice'];
   $pprices = $_POST['pprices'];
   $data = array();

   if($_FILES["product"]["name"][0]=="" || $_FILES["product"]["name"][0]==NULL)
    {
        echo "Image not Set";
    }
    else
    {
       for($i=0;$i<count($_FILES["product"]["name"]);$i++){
        if(isset($_FILES["product"]["name"][$i]) && $_FILES["product"]["name"][$i]!="")
        {
$file=$_FILES["product"]["name"][$i];
list($width,$height)=getimagesize($file);
  $nwidth=173;
  $nheight=230;
  $newimage=imagecreatetruecolor($nwidth,$nheight);
  $source=imagecreatefromjpeg($file);
  imagecopyresized($newimage,$source,0,0,0,0,$nwidth,$nheight,$width,$height);
  $file_name=time().'.jpg';
  $water=imagecreatefrompng('water.png');
  imagecopy($newimage,$water,round($nwidth/4),round($nheight/2),0,0,120,40);
  imagejpeg($newimage,'productimg/'.$file_name);
         $data[$i] = $file_name;


    }
    }


  

    $q = "INSERT INTO `products` (`ptitle`, `pdesc`, `pprice`, `pprices`, `img1`,`img2`,`img3`, `date`) VALUES ('$title','$desc','$pprice','$pprices','".$data[0]."','".$data[1]."','".$data[2]."','$date')";
  //  echo $qq;
   if( mysqli_query($dbconn,$q))
    {

           echo "<script>alert('added....');window.location.href='addproduct.php';</script>";
       }
        else
       {
          echo $q;

          // echo "<script>alert('Failed....');window.location.href='addproduct.php';</script>";
       }
    }




}






?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Vishnu Silk & Sarees - Pune</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php
            include('header.php');

        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->


                        <!-- Nav Item - Alerts -->


                        <!-- Nav Item - Messages -->


                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">VSS Shop</span>
                                <img class="img-profile rounded-circle"
                                    src="img/logo.jpg">
                            </a>
                            <!-- Dropdown - User Information -->
                             <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                               
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->


                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->


                        <!-- Earnings (Monthly) Card Example -->


                        <!-- Earnings (Monthly) Card Example -->


                        <!-- Pending Requests Card Example -->

                    </div>

                    <!-- Content Row -->



                        <!-- Area Chart -->


                        <!-- Pie Chart -->


                    <!-- Content Row -->
                    <div class="row">

                        <!-- Content Column -->



                        <div class="col-lg-9 mb-9">

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header ">
                                    <h6 class="m-0 font-weight-bold text-primary">Add Product Details</h6>
                                </div>
                                <div class="card-body">
                                    <div class="text-center">

                                    </div>
<form action="" method="POST" enctype="multipart/form-data" onload="setMinTomorow()">
  <div class="form-group">
    <label>Enter Product Title :</label>
    <input type="text" class="form-control" name="ptitle" >
  </div>

  <div class="form-group">
    <label >Enter Product Description :</label>
    <textarea class="form-control" name="pdesc"></textarea>
  </div>

  <div class="form-group">
    <label >Enter Product Price :</label>
      <input type="number" class="form-control" name="pprice" >
  </div>

  <div class="form-group">
    <label >Enter Our Price :</label>
      <input type="number" class="form-control" name="pprices" >
  </div>

  <div class="form-group">
    <label >Product Duration :</label>
      <input type="datetime" class="form-control" name="pduration" >
  </div>

  <div class="form-group">
    <label >Product Photo 1 :</label>
      <input type="file" accept="image/*" class="form-control" id="img1" name="product[0]" >
  </div>
  <div class="form-group">
    <label >Product Photo 2 :</label>
      <input type="file" accept="image/*" class="form-control"  id="img2" name="product[1]" >
  </div>
  <div class="form-group">
    <label >Product Photo 3 :</label>
      <input type="file" accept="image/*" class="form-control" id="img3" name="product[2]" >
  </div>
 <input type= "date" id="myDate" required>
  <button id="startBtn">SUBMIT</button>
  <button id="clearBtn">CLEAR</button>


  <button name="add" class="btn btn-primary">Add Product</button>
</form>


                                </div>
                            </div>

                            <!-- Approach -->


                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php
              include('footer.php');
           ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
     <script type="text/javascript">//variables
  var soundClock = new Audio("https://freespecialeffects.co.uk/soundfx/cartoon/pop1.wav");
  var soundAlarm = new Audio("https://freespecialeffects.co.uk/soundfx/sirens/fanfare3.wav");

  var startBtn = document.getElementById("startBtn");
  var clearBtn = document.getElementById("clearBtn");
  var myDate = document.getElementById("myDate");
  var demo = document.getElementById("demo");

  var dayTxt = document.getElementById("day"); 
  var hourTxt = document.getElementById("hour"); 
  var minuteTxt = document.getElementById("minute");  
  var secondTxt = document.getElementById("second");
  
  var tomorow;
  var counter;
  
  
function setMinTomorow() {
    var today = new Date();
    var dd = today.getDate()+1; // + tomorow!
    var mm = today.getMonth()+1; // January is 0!
    var yyyy = today.getFullYear();
      
    tomorow = yyyy+"-"+checkZero(mm)+"-"+checkZero(dd);
    myDate.setAttribute("min", tomorow);
  
    startBtn.addEventListener("click", startCounting);
    clearBtn.disabled = true; 
  }
  
  function checkZero(i) {
    if(i<10){
            i="0"+i;
    }
    return i;
  }
  

  function startCounting() {
    
      var findDate = myDate.value;
  if(findDate == "") {
      demo.innerHTML = "Choose date!"; 
      return false;
       } else {
      demo.innerHTML = ""; 
      startBtn.disabled = true;
      clearBtn.disabled = false;
      clearBtn.addEventListener("click", clearAll);
         
            var findDx = findDate.split("-");
            var year = findDx[0];
            var month = findDx[1];
            var day = findDx[2];
       
    var deadlineDate = month + " " + day + ", " + year + " 00:00:00";
    var deadline = new Date(deadlineDate).getTime(); 

counter = setInterval(function() { 
  
var now = new Date().getTime(); 

var t = deadline - now; 
  
var days = Math.floor(t / (1000 * 60 * 60 * 24)); 
var hours = Math.floor((t % (1000 * 60 * 60 * 24))/(1000 * 60 * 60)); 
var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60)); 
var seconds = Math.floor((t % (1000 * 60)) / 1000);   
  
dayTxt.innerHTML = days ; 
hourTxt.innerHTML = hours; 
minuteTxt.innerHTML = minutes;  
secondTxt.innerHTML =seconds;  
  

  soundClock.play();
  
if (t < 0) { 
        soundAlarm.play();
        clearInterval(counter); 
        demo.innerHTML = "TIME UP!"; 
        dayTxt.innerHTML ='0'; 
        hourTxt.innerHTML ='0'; 
        minuteTxt.innerHTML ='0';  
        secondTxt.innerHTML = '0'; } 
}, 1000); 
  }
  }

function clearAll() {
        clearInterval(counter); 
        dayTxt.innerHTML = ""; 
        hourTxt.innerHTML = ""; 
        minuteTxt.innerHTML = "";  
        secondTxt.innerHTML = "";
        clearBtn.disabled = true;
        startBtn.disabled = false;
   }
 </script>

</body>

</html>
<?php

}
else
{
   header('Location:404.php');
}

?>
