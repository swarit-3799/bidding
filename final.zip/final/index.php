<?php
session_start();
 include 'dbconn.php';
 date_default_timezone_set('Asia/Kolkata');
$date = date( 'Y-m-d H:i:s', time () );

 if(isset($_POST['register']))
 {
 	$name = $_POST['name'];
 	$email = $_POST['email'];
 	$mob = $_POST['mob'];
 	$hno = $_POST['hno'];
 	$city = $_POST['city'];
 	$pass = $_POST['pass'];
 	$pincode = $_POST['pincode'];

 	$q = "INSERT INTO `client`
 	(`name`, `email`, `mob`, `hno`, `city`, `pincode`, `password`, `date`) VALUES 
 	('$name','$email','$mob','$hno','$city','$pincode','$pass','$date')";
 	if(mysqli_query($dbconn,$q))
 	{
 		echo "<script>alert('sucessfully');windows.location.href='index.php';</script>";

 	}
 	else
 	{
   echo "<script>alert('faileddddd');</script>";
}
 	print_r($q);
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
</head>
  <style>

  	

.register-left{
    text-align: center;
    color: #fff;
   
}
.register-left input{
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    width: 60%;
    background: #f8f9fa;
    font-weight: bold;
    color: #383d41;
    margin-top: 30%;
    margin-bottom: 3%;
    cursor: pointer;
}

.register-left img{
    margin-top: 0%;
    margin-bottom: 0%;
    width: 60%;
    /*-webkit-animation: mover 2s infinite  alternate;
    animation: mover 1s infinite  alternate;*/
}
@-webkit-keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-20px); }
}
@keyframes mover {
    0% { transform: translateY(0); }
    100% { transform: translateY(-20px); }
}
.register-left p{
    font-weight: lighter;
    padding: 12%;
    margin-top: -9%;
}

.register-left a{
	color:red;
    }



  	
 
  body {
   
    /*background: -webkit-linear-gradient(left, #3931af, #00c6ff);*/
    background-image: url('assets/img/bg.jpg');

}
.panel-login {
	background-color: #00000069;
	-webkit-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);
	-moz-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);
	box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2);

}
.panel-login>.panel-heading {
	color: #00415d;
	background-color: #fff;
	border-color: #fff;
	text-align:center;
}
.panel-login>.panel-heading a{
	text-decoration: none;
	color: #666;
	font-weight: bold;
	font-size: 15px;
	-webkit-transition: all 0.1s linear;
	-moz-transition: all 0.1s linear;
	transition: all 0.1s linear;
}
.panel-login>.panel-heading a.active{
	color: #029f5b;
	font-size: 18px;
}
.panel-login>.panel-heading hr{
	margin-top: 10px;
	margin-bottom: 0px;
	clear: both;
	border: 0;
	height: 1px;
	background-image: -webkit-linear-gradient(left,rgba(0, 0, 0, 0),rgba(0, 0, 0, 0.15),rgba(0, 0, 0, 0));
	background-image: -moz-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
	background-image: -ms-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
	background-image: -o-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,0.15),rgba(0,0,0,0));
}
.panel-login input[type="text"],.panel-login input[type="email"],.panel-login input[type="password"] {
	height: 45px;
	border: 1px solid #ddd;
	font-size: 16px;
	-webkit-transition: all 0.1s linear;
	-moz-transition: all 0.1s linear;
	transition: all 0.1s linear;
}
.panel-login input:hover,
.panel-login input:focus {
	outline:none;
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
	box-shadow: none;
	border-color: #ccc;
}
.btn-login {
	background-color: #59B2E0 !important;
	outline: none;
	color: #fff;
	font-size: 14px;
	height: auto;
	font-weight: normal;
	padding: 14px 0;
	text-transform: uppercase;
	border-color: #59B2E6;
}
.btn-login:hover,
.btn-login:focus {
	color: #fff;
	background-color: #53A3CD;
	border-color: #53A3CD;
}
.forgot-password {
	text-decoration: underline;
	color: #888;
}
.forgot-password:hover,
.forgot-password:focus {
	text-decoration: underline;
	color: #666;
}

.btn-register {
	background-color: #1CB94E;
	outline: none;
	color: #fff;
	font-size: 14px;
	height: auto;
	font-weight: normal;
	padding: 14px 0;
	text-transform: uppercase;
	border-color: #1CB94A;
}
.btn-register:hover,
.btn-register:focus {
	color: #fff;
	background-color: #1CA347;
	border-color: #1CA347;
}
 .icon { 
            padding: 10px; 
            min-width: 60px; 
                padding-top: 14px;
         padding-left: 18px;
         color: white;
        } 
        .input-icons i { 
            position: absolute; 
        } 
          
        .input-icons { 
            width: 100%; 
            margin-bottom: 10px; 
        } 


  </style>

<script>
	$(function() {

    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

});

function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function myFunction1() {
  var x = document.getElementById("myInputt");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

<body>
	 

<div class="container">


	
  	
    	<div class="row">
    		
			
				<div class="col-md-4 col-md-offset-4 text-center register-left"><br>
                       <img src="assets/img/logo.png" alt=""/>
                        
                        
                    </div><br>
			

    		

			<div class="col-md-6 col-md-offset-3"><br>
				<div class="panel panel-login">
					<div class="panel-heading" style="background-color: #02020252;">
						<div class="row">
							<div class="col-xs-6">
								<a href="#" class="active" id="login-form-link" style="color: white;">Login</a>
							</div>
							<div class="col-xs-6">
								<a href="#" id="register-form-link" style="color: white;">Register</a>
							</div>
						</div>
						<hr>
					</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-lg-12">
								<form id="login-form" action="check.php" method="post" role="form" style="display: block;">
									<div class="form-group">
										 <div class="input-icons"> 
										 <i class="fa fa-user icon"></i> 
										<input type="text" name="mobile" id="username" tabindex="1" class="form-control" placeholder="Mobile Number" value="" style="text-align: center;color: white;" >
</div>
									</div>
									<div class="form-group">
										<div class="input-icons"> 
										<i class="fa fa-key icon">  </i> 
										<input type="password" name="password" id="myInput" tabindex="2" class="form-control" placeholder="Password" style="text-align: center;color: white;" ><br>
										<input type="checkbox" onclick="myFunction()">&nbsp;<span style="color: white;">Show Password</span>
									</div>
									</div>
									<div class="form-group text-center">
										
										<!--<label for="remember"><a href="" >forgot password</a></label> -->
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="login"  tabindex="4" class="form-control btn btn-login" class="dropdown-item thm-bg-mnu-itm" 
												role="presentation" data-toggle="modal" data-target="#alert-modal" value="Log In">
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-lg-12">
												<div class="text-center">
													<a href="https://phpoll.com/recover" tabindex="5" class="forgot-password">forgot password ?</a>
												</div>
											</div>
										</div>
									</div>
								</form>
								<form id="register-form" action="" class="c" method="POST" role="form" style="display: none;">
									<div class="form-group">
										<div class="input-icons">
										<i class="fa fa-user-circle-o icon" aria-hidden="true"></i>
										<input type="text" name="name" id="username" tabindex="1" class="form-control" placeholder="Enter Name" value="" style="text-align: center;color: white;"></div>
									</div>
									<div class="form-group">
										<div class="input-icons">
											<i class="fa fa-envelope icon"></i>
										<input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email Address" value="" style="text-align: center;color: white;"></div>
									</div>
									<div class="form-group">
										<div class="input-icons">
										<i class="fa fa-phone icon" aria-hidden="true"></i>
										<input type="number" name="mob" id="username" tabindex="1" class="form-control" placeholder="Contact Number" value="" style="text-align: center;color: white;"></div>
									</div>
									
									<div class="form-group">
										<div class="input-icons">
										<i class="fa fa-home icon" aria-hidden="true"></i>
										<input type="text" name="hno" id="email" tabindex="1" class="form-control" placeholder="Address ...." value="" style="text-align: center;color: white;"> </div>
									</div>
									<div class="form-group">
										<div class="input-icons">
										<i class="fa fa-location-arrow icon" aria-hidden="true"></i>
										<input type="text" name="city" id="email" tabindex="1" class="form-control" placeholder="City" value="" style="text-align: center;color: white;"> </div>
									</div>
									<div class="form-group">
										<div class="input-icons">
										<i class="fa fa-map-pin icon" aria-hidden="true"></i>
										<input type="text" name="pincode"  tabindex="1" class="form-control" placeholder="pincode" value="" style="text-align: center;color: white;"> </div>
									</div>
									<div class="form-group">
										<div class="input-icons">
										<i class="fa fa-lock icon" aria-hidden="true"></i>
										<input type="password" name="pass" id="myInputt" tabindex="2" class="form-control" placeholder="Password" style="text-align: center;color: white;"></div>
										
										<input type="checkbox" onclick="myFunction1()">&nbsp;Show Password
									</div>
									
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="register"  tabindex="4" class="form-control btn btn-login" value="Register Now" name="register" >
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<p class=" register-left text-center">Copyright © 2020 | Vishnu Silk & Sarees | Designed & Developed By - <a href="http://softechcoders.in">Softech Coders</a></p>
	</div>

</body>
</html>