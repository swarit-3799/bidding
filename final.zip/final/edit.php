<?php
session_start();
include('dbconn.php');
if(isset($_SESSION['client_id']))
{
if(isset($_POST['update']))
{
    if(isset($_FILES["profile_pic"]) && $_FILES["profile_pic"]["name"]!="") {

      // print_r($_FILES);
      $filename = $_FILES['profile_pic']['name'];
      $filetmpname = $_FILES['profile_pic']['tmp_name'];
      $folder = 'clientprofilephoto/';
      move_uploaded_file($filetmpname, $folder.$filename);
      $email = $_POST['email'];
          $hno = $_POST['address'];
          $city = $_POST['city'];
          $password = $_POST['password'];

          $que= "UPDATE `client` SET `profile`='".$filename."',`email` = '$email' , `city` = '$city' , `hno` = '$hno', `password` = '$password' WHERE `client_id` = '".$_SESSION['client_id']."' ";
     // print_r($que);

         if(mysqli_query($dbconn,$que))
          {
              echo "<script>alert('Data is Updated');window.location.href='edit.php';</script>";
          }



          else
              {echo "<script>alert('failedd');window.location.href='edit.php';</script>";}
    } else {

        $email = $_POST['email'];
    $hno = $_POST['address'];
    $city = $_POST['city'];
    $password = $_POST['password'];

    $que= "UPDATE `client` SET `email` = '$email' , `city` = '$city' , `hno` = '$hno', `password` = '$password' WHERE `client_id` = '".$_SESSION['client_id']."' ";
    //print_r($que);

   if(mysqli_query($dbconn,$que))
    {
        echo "<script>alert('Data is Updated');window.location.href='edit.php';</script>";
    }



    else
        {echo "<script>alert('failedd');window.location.href='edit.php';</script>";}
      }
}




?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Vishnu Silk &amp; Sarees</title>
    <meta property="og:title" content="Vishnu silk &amp; Sarees">
    <meta property="og:type" content="website">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:image" content="assets/img/lg.jpg">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/mob.css">
    <link rel="stylesheet" href="assets/css/pc.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
    <style type="text/css">
        .edit-frm {
 
    width: 45%;
    margin: auto;
}
.hf-circ-blk{
    background-image: url('assets/img/bg.jpg');
    background-position: center;
    background-size: cover;
}
.thm-bg
{
       background-image: url('assets/img/bg.jpg');
    background-position: center; 
    background-size: cover;
}
.edit-ip{
  color: white;
}
.form-control:disabled{
  background-color: transparent;
}
.form-control {
  color: white;
}

    </style>
</head>

<body class="edit-bg" style="background-image: url('assets/img/bgg.jpg');color: #d3dae0;">
    <div class="hf-circ-nxt">
        <div class="dropdown drp-dwn"><a class="thm-bg drp-dwn-btn" data-toggle="dropdown" aria-expanded="true"><i class="icon ion-chevron-down dropdown-icn"></i></a>
            <div class="jello animated dropdown-menu thm-bg thm-bg-mnu" role="menu"><a class="dropdown-item thm-bg-mnu-itm" href="index2.php" role="presentation"><i class="fas fa-home" style="color: #ab5959;"></i>&nbsp;Home</a><a class="dropdown-item thm-bg-mnu-itm" href="order.php" role="presentation"><i class="fas fa-shipping-fast" style="color: rgb(255,214,0);"></i>&nbsp;My Orders</a>
                <a
                    class="dropdown-item thm-bg-mnu-itm" href="bid.php" role="presentation"><i class="fa fa-gavel" style="color: rgb(10,167,255);"></i>&nbsp; My Bid's</a><a class="dropdown-item thm-bg-mnu-itm" href="point.php" role="presentation"><i class="fa fa-diamond" style="color: rgb(255,0,168);"></i>&nbsp; Points</a>
                    <a
                        class="dropdown-item thm-bg-mnu-itm" href="about.php" role="presentation"><i class="fa fa-phone" style="color: green;"></i>&nbsp; Contact Us</a><a
                                class="dropdown-item thm-bg-mnu-itm" href="logout.php" role="presentation"><i class="fa fa-power-off" style="color: black;"></i>&nbsp; Logout</a></div>
        </div>
    </div>
    <div class="body1">
        <div class="prof-mn-dv">
             <div class="hf-circ-blk">
              <?php
              $qq = "SELECT * FROM `client` WHERE `status` = '1' AND `client_id` = '".$_SESSION['client_id']."' ";
             $r = mysqli_fetch_array(mysqli_query($dbconn,$qq));
             // print_r($r);
             ?>
                <div class="swing animated prof-bk-dv"><img class="prof" src="clientprofilephoto/<?php if($r["profile"]=="" || $r["profile"]==null) {
                  echo "default.png";
                } else {
                  echo $r["profile"];
                } ?>"></div>
            </div>
            <form class="edit-frm" enctype="multipart/form-data" action="" method="POST"><br>
            <div class="choose-img"><a class="choose-img-icn-bk" style="    margin-left: -2rem;" href="" 
               ><i class="fa fa-camera" style="color: white;"></i>&nbsp;Edit<input type="file" name="profile_pic" accept="image/*"></a>&nbsp;<a class="logout-bck thm-bg" href="logout.php" style="text-decoration: none;color:white;">&nbsp;<i class="fa fa-power-off" style="text-decoration: none;"></i>&nbsp;Logout</a></div>
        </div>

        <?php
           $qq = "SELECT * FROM `client` WHERE `status` = '1' AND `client_id` = '".$_SESSION['client_id']."' ";
          $r = mysqli_query($dbconn,$qq);
          while($row = mysqli_fetch_array($r))
          {
          echo '

            <div class="edit-ip-bck"><span class="edit-ip-label">Name:</span><input class="form-control edit-ip" type="text" id="name" name="name" value="'.$row['name'].'" disabled name="names"></div>
            <div class="edit-ip-bck"><span class="edit-ip-label">Phone:</span><input class="form-control edit-ip" type="tel" value="'.$row['mob'].'" disabled name="mob" style="background:tranparent;"></div>
            <div class="edit-ip-bck"><span class="edit-ip-label">E-mail:</span><input class="form-control edit-ip" type="email" id="name" name="email" value="'.$row['email'].'"></div>
            <div class="edit-ip-bck"><span class="edit-ip-label">Address:</span><input class="form-control edit-ip" type="text" id="name" name="address" value="'.$row['hno'].'"></div>
            <div class="edit-ip-bck"><span class="edit-ip-label">City</span><input class="form-control edit-ip" type="text" id="name" name="city" value="'.$row['city'].'"></div>
            <div class="edit-ip-bck"><span class="edit-ip-label">Password:</span><input class="form-control edit-ip" type="password" name="password" id="myinputt" value="'.$row['password'].'"></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" onclick="myFunction()"/>&nbsp;Show Password
            <div class="edit-ip-bck btn-back"><button class="btn btn-primary"  name="update">Update</button></div>
        </form>  ';}

        ?>
    </div>
    <div class="bg-light footer-basic">
        <footer class="text-dark footer">
            <div class="social"><img class="foot-lg" src="assets/img/logo.png"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
            <p class="copyright">© 2020 Vishnu Silk &amp; Sarees | Developed By - Softech Coders</p>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script>
            function myFunction() {
  var x = document.getElementById("myinputt");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</body>

</html>
<?php

}
else
{
    header('Location:404.php');
}
?>