<?php
session_start();
include 'dbconn.php';
if(isset($_SESSION['client_id']))
 {
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Vishnu Silk &amp; Sarees</title>
    <meta property="og:title" content="Vishnu silk &amp; Sarees">
    <meta property="og:type" content="website">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:image" content="assets/img/lg.jpg">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/mob.css">
    <link rel="stylesheet" href="assets/css/pc.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
    <style type="text/css">
        legend {
  width: fit-content;
  margin-left: 10px;
  max-width: 100%;
  padding: 0px 5px;
  margin-bottom: 0;
}

@media (min-width: 992px) {
  .cust-pan-bid-ip {
    width: 40%;
    margin-right: 5px;
    border: none;
    outline: none;
  }
}

@media (max-width: 768px) {
  .cust-pan-bid-ip {
    /*position: relative;*/
    width: 100%;
    margin-right: 5px;
    border: none;
    outline: none;
  }
}
input:focus {
    border-bottom: solid black 1px;
    transition: 200ms;
    transition-timing-function: ease-in-out;
}

.hf-circ-blk{
    background-image: url('assets/img/bg.jpg');
    background-position: center;
    background-size: cover;
}
.thm-bg
{
       background-image: url('assets/img/bg.jpg');
    background-position: center;
    background-size: cover;
}
.w-100{
    border-radius: 10px;
}

    </style>

</head>

<body>
   <div class="modal fade alert-modal" role="dialog" tabindex="-1" id="alert-modal">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body text-center alert-modal-body"><img class="alert-img" src="assets/img/check-circle.gif">
                    <p class="text-center">Are You Sure To Logout</p>
                </div>
                <div class="modal-footer d-flex justify-content-center justify-content-xl-center alert-modal-footer"><button class="btn btn-danger" type="button" data-dismiss="modal">Cancle</button><button class="btn btn-primary" type="button" onclick="window.location.href='logout.php';">Ok</button></div>
            </div>
        </div>
    </div>
    <?php
    $q = "SELECT * FROM `products` WHERE `status` = '1'";
    $r = mysqli_query($dbconn,$q);
    while($row = mysqli_fetch_array($r))
    {
        echo '
            <div class="modal fade sldr-prv-pop" role="dialog" tabindex="-1" id="sldr-prv-pop">
                <div class="modal-dialog sldr-prv-pop-dlg" role="document">
                    <div class="modal-content sldr-prv-pop-cnt">
                        <div class="modal-header">
                            <h6 class="modal-title">'.$row['ptitle'].'</h6><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                        <div class="modal-body">
                            <div class="carousel slide" data-ride="carousel" id="carousel-1">
                                <div class="carousel-inner" role="listbox">
                                    <div class="carousel-item"><img class="w-100 d-block" src="dash/productimg/'.$row["img1"].'" alt="Slide Image"></div>
                                    <div class="carousel-item active"><img class="w-100 d-block" src="dash/productimg/'.$row["img2"].'"alt="Slide Image"></div>
                                    <div class="carousel-item"><img class="w-100 d-block" src="dash/productimg/'.$row["img3"].'" alt="Slide Image"></div>
                                </div>
                                <div><a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev"><span class="carousel-control-prev-icon"></span><span class="sr-only">Previous</span></a><a class="carousel-control-next" href="#carousel-1" role="button"
                                        data-slide="next"><span class="carousel-control-next-icon"></span><span class="sr-only">Next</span></a></div>
                                <ol class="carousel-indicators">
                                    <li data-target="#carousel-1" data-slide-to="0"></li>
                                    <li data-target="#carousel-1" data-slide-to="1" class="active"></li>
                                    <li data-target="#carousel-1" data-slide-to="2"></li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            ';
    }
    ?>
    <div class="body1">
        <div class="prof-mn-dv">
           <div class="hf-circ-blk">
            <a href="edit.php">
              <?php
              $qq = "SELECT * FROM `client` WHERE `status` = '1' AND `client_id` = '".$_SESSION['client_id']."'";
             $r = mysqli_fetch_array(mysqli_query($dbconn,$qq));
             // print_r($r);
             ?>
                <div class="swing animated prof-bk-dv"><img class="prof" src="clientprofilephoto/<?php if($r["profile"]=="" || $r["profile"]==null) {
                  echo "default.png";
                } else {
                  echo $r["profile"];
                } ?>"></div>
            </a>
            </div>

            <div class="hf-circ-nxt">
                <div class="dropdown drp-dwn"><a class="thm-bg drp-dwn-btn" data-toggle="dropdown" aria-expanded="true"><i class="icon ion-chevron-down dropdown-icn"></i></a>
                    <div class="jello animated dropdown-menu thm-bg thm-bg-mnu" role="menu"><a class="dropdown-item thm-bg-mnu-itm" href="index2.php" role="presentation"><i class="fas fa-home" style="color: #ab5959;"></i>&nbsp;Home</a><a class="dropdown-item thm-bg-mnu-itm" href="order.php" role="presentation"><i class="fas fa-shipping-fast" style="color: rgb(255,214,0);"></i>&nbsp;My Orders</a>
                        <a
                            class="dropdown-item thm-bg-mnu-itm" href="bid.php" role="presentation"><i class="fa fa-gavel" style="color: rgb(10,167,255);"></i>&nbsp; My Bid's</a><a class="dropdown-item thm-bg-mnu-itm" href="point.php" role="presentation"><i class="fa fa-diamond" style="color: rgb(255,0,168);"></i>&nbsp; Points</a>
                            <a
                                class="dropdown-item thm-bg-mnu-itm" href="about.php" role="presentation"><i class="fa fa-phone" style="color: green;"></i>&nbsp; Contact Us</a>
                                <a class="dropdown-item thm-bg-mnu-itm" style="color:black;" data-toggle="modal" data-target="#alert-modal" role="presentation"><i class="fa fa-power-off" style="color: black;"></i>&nbsp; Logout</a>
                               <!-- <a class="dropdown-item thm-bg-mnu-itm" role="presentation" data-toggle="modal" data-target="#alert-modal" href="contact.php"><i class="fa fa-phone" style="color: rgb(18,131,0);"></i>&nbsp; Contact Us</a>--></div>
                </div>
                <?php
                $q1 = "SELECT * FROM `client` WHERE `status` = '1' AND `client_id` = '".$_SESSION['client_id']."' ";
                $res = mysqli_query($dbconn,$q1);
                while ($row = mysqli_fetch_array($res))
                {
                echo '
                <div><label class="prof-unm">'.$row['name'].'</label></div>
                ';
                 }
                ?>
                <?php
                $total_points = 0;
                $q1 = "SELECT SUM(`points`) FROM `points` WHERE `client_id`='".$_SESSION["client_id"]."' AND `type`='1' AND `status`='1'";
                $r = mysqli_query($dbconn,$q1);
                while($row = mysqli_fetch_assoc($r)) {
                  $total_points = $row["SUM(`points`)"];
                }
                $q1 = "SELECT SUM(`points`) FROM `points` WHERE `client_id`='".$_SESSION["client_id"]."' AND `type`='2' AND `status`='1'";
                $r = mysqli_query($dbconn,$q1);
                while($row = mysqli_fetch_assoc($r)) {
                  $total_points -= $row["SUM(`points`)"];
                }
                ?>
                <div><label class="prof-unm lbls">Points</label><label class="pulse animated infinite count"><i class="fa fa-diamond" style="background-image: url('assets/img/bg.jpg')background-size:cover;background-position: center;"></i>&nbsp;<?php echo $total_points; ?></label></div>
            </div>
        </div>

            <?php

    $q = "SELECT * FROM `products` WHERE `status` = '1'";
    $r = mysqli_query($dbconn,$q);
    while($ro = mysqli_fetch_array($r))
    {

            echo '
             <div class="cust-pan">
            <div>
                <div class="row">
                    <div class="col hf-width">
                        <div class="carousel slide" data-ride="carousel" id="carousel-1" data-toggle="modal" data-target="#sldr-prv-pop">
                            <div class="carousel-inner" role="listbox">
                                <div class="carousel-item"><img class="w-100 d-block" src="dash/productimg/'.$ro["img1"].'" alt="Slide Image"></div>
                                <div class="carousel-item"><img class="w-100 d-block" src="dash/productimg/'.$ro["img2"].'"alt="Slide Image"></div>
                                <div class="carousel-item active"><img class="w-100 d-block" src="dash/productimg/'.$ro["img3"].'" alt="Slide Image"></div>
                            </div>
                            <div><a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev"><span class="carousel-control-prev-icon"></span><span class="sr-only">Previous</span></a><a class="carousel-control-next" href="#carousel-1"
                                    role="button" data-slide="next"><span class="carousel-control-next-icon"></span><span class="sr-only">Next</span></a></div>
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-1" data-slide-to="0"></li>
                                <li data-target="#carousel-1" data-slide-to="1"></li>
                                <li data-target="#carousel-1" data-slide-to="2" class="active"></li>
                            </ol>
                        </div>
                    </div>
                    <div class="col hf-width">
                        <div class="jello animated infinite"
                        style="

    /* transform: rotate(45deg); */
    position: absolute;
    /* float: right; */
    /* width: 100%; */
    margin: auto;
    font-size: 12px;
    right: 5px;
    top: -8px;
    background: #0c6cfd30;
    color: #0072ff;
    padding: 0.1rem 1.5rem;
    border-bottom-left-radius: 10px;
    border-top-right-radius: 10px;

"
><i class="fa fa-gavel"></i> ';
$qqq = "SELECT count(`product_id`) FROM `bid` WHERE `product_id`='".$ro["product_id"]."' ";
$cnt = 0;
//echo $qqq;
$rr = mysqli_query($dbconn,$qqq);
while($r = mysqli_fetch_assoc($rr))
{
  $cnt = $r["count(`product_id`)"];
}
echo $cnt;

echo' </div>
                   <br>     <br><h6 class="prod-lbl">'.$ro['ptitle'].'<br></h6>
                        <div class="dtls-div"><label class="dtls-lbl">Details....</label><a class="mor-btn" data-toggle="modal" data-target="#dtls-pop">More&nbsp;<i class="fa fa-angle-down"></i></a></div>
                        <div class="count-down-bck pulse animated infinite"><label class="cust-pan-lbls">End up !&nbsp;</label><span class=" count-down">
                        <div id="clockdiv"> 
  <div> 
    <span id="day"></span> <span id="hour"></span> <span id="minute"></span> 
    <span id="second"></span>
 
  </div>
</div> 








                        </span></div>
                        <div><label class="cust-pan-lbls">Market Price :&nbsp;</label><label class="cust-pan-lbls thm-clr">'.$ro['pprice'].' /-</label></div>
                        <div><label class="cust-pan-lbls">Our Price :&nbsp;</label><label class="cust-pan-lbls green-clr">'.$ro['pprices'].' /-</label></div>
                        <div class="d-flex align-items-center">
                          <form method="post" action="bidop.php" id="bidform'.$ro["product_id"].'" class="d-flex align-items-center">

                            <input type="hidden" name="product_id" value="'.$ro["product_id"].'">
                            <input type="hidden" name="flag" value="bid">

    <fieldset class="border mr-2">
        <legend class="shadow-none cust-pan-lbls">Bid Price:</legend><input type="number" class="cust-pan-bid-ip pl-2" required id="price'.$ro["product_id"].'" name="price" /></fieldset>
          ';
                            if ($ro["disable"] == 0)
                            {
                                echo '


                            <button style="background:none;border:none;" type="submit">
                              <img /*onclick="document.getElementById(\'bidform'.$ro["product_id"].'\').submit();"*/ class="tada animated infinite ord-icn" src="assets/img/order.png">
                            </button> ';
                        }
                            echo '
        </div>


                        </div>
                        </form>
                    </div>
                </div>
                <div class="scrl-dv">
                    ';
                    $q = "SELECT `bid_id`, `product_id`, `winner`,`client_id`, `price`, `date`, `status` FROM `bid` WHERE `product_id`='".$ro["product_id"]."' ORDER BY `price` DESC LIMIT 5";
                    $r1 = mysqli_query($dbconn,$q);
                    while ($row = mysqli_fetch_assoc($r1)){
                        $img = "";
                        $name = "";
                        $city = "";
                        $q2 = "SELECT `client_id`, `name`, `profile`, `email`, `mob`, `hno`, `city`, `pincode`, `password`, `date`, `status` FROM `client` WHERE `client_id`='".$row["client_id"]."'";
                        $r2 = mysqli_query($dbconn,$q2);
                        while($ro2 = mysqli_fetch_array($r2)) {
                            $img = $ro2["profile"];
                            $name = $ro2["name"];
                            $city = $ro2["city"];
                        }
                        echo '
                        <div class="scrl-box">
                        <div>';
                        if($row["winner"]==1) {
                            echo '
                        <small class="jello animated infinite hd-win thm-bg">Winner</small>';
                        }
                        echo '<small class="hd-tim">
                        <time class="timeago" datetime="'.$row["date"].'" ></time>

                        </small>
                        </div>
                        <div class="scrl-box-prc-dv">
                            <h6 class="scrl-box-prc">'.$row['price'].'</h6>
                        </div>';


                        echo '<img class="scrl-box-img" src="clientprofilephoto/'; if($img=="" || $img==null) {
                  echo "default.png";
                } else {
                  echo $img;
                } echo '">
                        <p class="scrl-box-prc-dv name">'.$name.'<br></p>
                        <p class="scrl-box-prc-dv name locat">'.$city.'<br></p>
                    </div>


                        ';
                    }


                     echo '

                </div>
            </div>
        </div><br>' ;} ?><br><br>

    </div>
    <div class="bg-light footer-basic">
        <footer class="text-dark footer">
            <div class="social"><img class="foot-lg" src="assets/img/logo.png"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
            <p class="copyright">© 2020 Vishnu Silk &amp; Sarees | Developed By - Softech Coders</p>
        </footer>
    </div>
             <?php

    $q = "SELECT * FROM `products` WHERE `status` = '1'";
    $r = mysqli_query($dbconn,$q);
    while($ro = mysqli_fetch_array($r))
    {
        echo '
        <div class="modal fade dtls-pop" role="dialog" tabindex="-1" id="dtls-pop">
        <div class="modal-dialog dtls-pop-dlg" role="document">
            <div class="modal-content dtls-pop-cnt">
                <div class="modal-header dtls-pop-hd">
                    <h6 class="modal-title">Details</h6><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                <div class="modal-body dtls-pop-bd">
                    <p><br>&nbsp;'.$ro['pdesc'].'</p>
                </div>
            </div>
        </div>
        </div> ';
      }
    ?>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="assets/jquery.timeago.js"></script>
<script type="text/javascript">

  jQuery(document).ready(function(){
    $("time.timeago").timeago();
  });
</script>
</body>

</html>
<?php

}
else
{
    header('Location:../404.php');
}

?>
