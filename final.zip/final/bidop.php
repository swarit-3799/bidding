<?php
  session_start();
  require_once 'dbconn.php';
   date_default_timezone_set('Asia/Kolkata');
   $date = date( 'Y-m-d H:i:s', time () );
  if(isset($_SESSION["client_id"])) {
    //print_r($_POST);
    $query = "INSERT INTO `bid`(`product_id`, `client_id`, `price`, `date`) VALUES 
    ('".$_POST['product_id']."','".$_SESSION['client_id']."' , '".$_POST['price']."', '$date' )";
    //print_r($query);
    if(mysqli_query($dbconn,$query))
    {
    	header('Location:index2.php');
    }
    else
    {
    	echo "failedd";
    }
  } else {
    echo "<script>window.location.href='index.php';</script>";
  }
?>
