<?php


 $dbconn = mysqli_connect("localhost","root","","sw_bid");
 if(!$dbconn)
 {
 	echo "Database Failed";
 }

?>
