<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Vishnu Silk &amp; Sarees</title>
    <meta property="og:title" content="Vishnu silk &amp; Sarees">
    <meta property="og:type" content="website">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:image" content="assets/img/lg.jpg">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/mob.css">
    <link rel="stylesheet" href="assets/css/pc.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
</head>

<body>
    <div class="hf-circ-nxt">
        <div class="dropdown drp-dwn"><a class="thm-bg drp-dwn-btn" data-toggle="dropdown" aria-expanded="true"><i class="icon ion-chevron-down dropdown-icn"></i></a>
            <div class="jello animated dropdown-menu thm-bg thm-bg-mnu" role="menu"><a class="dropdown-item thm-bg-mnu-itm" href="index.php" role="presentation"><i class="fas fa-home" style="color: #ab5959;"></i>&nbsp;Home</a><a class="dropdown-item thm-bg-mnu-itm" href="order.php" role="presentation"><i class="fas fa-shipping-fast" style="color: rgb(255,214,0);"></i>&nbsp;My Orders</a>
                <a
                    class="dropdown-item thm-bg-mnu-itm" href="bid.php" role="presentation"><i class="fa fa-gavel" style="color: rgb(10,167,255);"></i>&nbsp; My Bid's</a><a class="dropdown-item thm-bg-mnu-itm" href="point.php" role="presentation"><i class="fa fa-diamond" style="color: rgb(255,0,168);"></i>&nbsp; Points</a>
                    <a
                        class="dropdown-item thm-bg-mnu-itm" href="about.php" role="presentation"><i class="fa fa-info-circle" style="color: rgb(255,153,0);"></i>&nbsp; About Us</a><a class="dropdown-item thm-bg-mnu-itm" role="presentation" data-toggle="modal" data-target="#alert-modal" href="contact.php"><i class="fa fa-phone" style="color: rgb(18,131,0);"></i>&nbsp; Contact Us</a></div>
        </div>
    </div>
    <div class="contact-clean">
        <form method="post">
            <h2 class="text-center">Contact us</h2>
            <div class="form-group"><input class="form-control" type="text" name="name" placeholder="Name"></div>
            <div class="form-group"><input class="form-control is-invalid" type="email" name="email" placeholder="Email"><small class="form-text text-danger">Please enter a correct email address.</small></div>
            <div class="form-group"><textarea class="form-control" name="message" placeholder="Message" rows="14"></textarea></div>
            <div class="form-group"><button class="btn btn-primary" type="submit">send </button></div>
        </form>
    </div>
    <div class="bg-light footer-basic">
        <footer class="text-dark footer">
            <div class="social"><img class="foot-lg" src="assets/img/logo.png"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
            <p class="copyright">Vishnu Silk &amp; Sarees © 2020</p>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>