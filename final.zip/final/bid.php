<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Vishnu Silk &amp; Sarees</title>
    <meta property="og:title" content="Vishnu silk &amp; Sarees">
    <meta property="og:type" content="website">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:image" content="assets/img/lg.jpg">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/mob.css">
    <link rel="stylesheet" href="assets/css/pc.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
</head>

<body>
    <div class="prof-mn-dv">
        <div class="hf-circ-nxt">
            <div class="dropdown drp-dwn"><a class="thm-bg drp-dwn-btn" data-toggle="dropdown" aria-expanded="true"><i class="icon ion-chevron-down dropdown-icn"></i></a>
                <div class="jello animated dropdown-menu thm-bg thm-bg-mnu" role="menu"><a class="dropdown-item thm-bg-mnu-itm" href="index.php" role="presentation"><i class="fas fa-home" style="color: #ab5959;"></i>&nbsp;Home</a><a class="dropdown-item thm-bg-mnu-itm" href="order.php" role="presentation"><i class="fas fa-shipping-fast" style="color: rgb(255,214,0);"></i>&nbsp;My Orders</a>
                    <a
                        class="dropdown-item thm-bg-mnu-itm" href="bid.php" role="presentation"><i class="fa fa-gavel" style="color: rgb(10,167,255);"></i>&nbsp; My Bid's</a><a class="dropdown-item thm-bg-mnu-itm" href="point.php" role="presentation"><i class="fa fa-diamond" style="color: rgb(255,0,168);"></i>&nbsp; Points</a>
                        <a
                            class="dropdown-item thm-bg-mnu-itm" href="about.php" role="presentation"><i class="fa fa-info-circle" style="color: rgb(255,153,0);"></i>&nbsp; About Us</a><a class="dropdown-item thm-bg-mnu-itm" role="presentation" data-toggle="modal" data-target="#alert-modal" href="contact.php"><i class="fa fa-phone" style="color: rgb(18,131,0);"></i>&nbsp; Contact Us</a></div>
            </div>
        </div>
    </div>
    <div class="body1">
        <div class="prof-mn-dv"></div>
        <div class="cust-pan">
            <div>
                <div class="row">
                    <div class="col hf-width">
                        <div class="carousel slide" data-ride="carousel" id="carousel-1" data-toggle="modal" data-target="#sldr-prv-pop">
                            <div class="carousel-inner" role="listbox">
                                <div class="carousel-item"><img class="w-100 d-block" src="assets/img/im.jpg" alt="Slide Image"></div>
                                <div class="carousel-item active"><img class="w-100 d-block" src="assets/img/0de29cfd26aa09bcc40db0b9225dd89d.jpg" alt="Slide Image"></div>
                                <div class="carousel-item"><img class="w-100 d-block" src="https://cdn.bootstrapstudio.io/placeholders/1400x800.png" alt="Slide Image"></div>
                            </div>
                            <div><a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev"><span class="carousel-control-prev-icon"></span><span class="sr-only">Previous</span></a><a class="carousel-control-next" href="#carousel-1"
                                    role="button" data-slide="next"><span class="carousel-control-next-icon"></span><span class="sr-only">Next</span></a></div>
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-1" data-slide-to="0"></li>
                                <li data-target="#carousel-1" data-slide-to="1" class="active"></li>
                                <li data-target="#carousel-1" data-slide-to="2"></li>
                            </ol>
                        </div>
                    </div>
                    <div class="col hf-width">
                        <div></div>
                        <h6 class="prod-lbl">Name of product<br></h6>
                        <div class="dtls-div"><label class="dtls-lbl">(red color) t-shirt&nbsp;<br></label><a class="mor-btn" data-toggle="modal" data-target="#dtls-pop">More&nbsp;<i class="fa fa-angle-down"></i></a></div>
                        <div><label class="cust-pan-lbls">Original Price :&nbsp;</label><label class="cust-pan-lbls thm-clr">1000$</label></div>
                        <div><label class="cust-pan-lbls">Our Price :&nbsp;</label><label class="cust-pan-lbls green-clr">900$</label></div>
                        <div><label class="cust-pan-lbls">Bid price :&nbsp;</label><input type="number" class="cust-pan-bid-ip"></div>
                    </div>
                </div>
              
            </div>
        </div>
    </div>
    <div class="modal fade dtls-pop" role="dialog" tabindex="-1" id="dtls-pop">
        <div class="modal-dialog dtls-pop-dlg" role="document">
            <div class="modal-content dtls-pop-cnt">
                <div class="modal-header dtls-pop-hd">
                    <h6 class="modal-title">Details</h6><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                <div class="modal-body dtls-pop-bd">
                    <p><br>&nbsp; I have read all the rules of admission and on understanding these Rules, I have filled this Application Form for Admission to First Year Under Graduate Technical Course in B.Pharmacy &amp; Post Graduate<br><br></p>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade sldr-prv-pop" role="dialog" tabindex="-1" id="sldr-prv-pop">
        <div class="modal-dialog sldr-prv-pop-dlg" role="document">
            <div class="modal-content sldr-prv-pop-cnt">
                <div class="modal-header">
                    <h6 class="modal-title">Name of product</h6><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                <div class="modal-body">
                    <div class="carousel slide" data-ride="carousel" id="carousel-1">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item"><img class="w-100 d-block" src="assets/img/im.jpg" alt="Slide Image"></div>
                            <div class="carousel-item active"><img class="w-100 d-block" src="assets/img/0de29cfd26aa09bcc40db0b9225dd89d.jpg" alt="Slide Image"></div>
                            <div class="carousel-item"><img class="w-100 d-block" src="https://cdn.bootstrapstudio.io/placeholders/1400x800.png" alt="Slide Image"></div>
                        </div>
                        <div><a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev"><span class="carousel-control-prev-icon"></span><span class="sr-only">Previous</span></a><a class="carousel-control-next" href="#carousel-1" role="button"
                                data-slide="next"><span class="carousel-control-next-icon"></span><span class="sr-only">Next</span></a></div>
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-1" data-slide-to="0"></li>
                            <li data-target="#carousel-1" data-slide-to="1" class="active"></li>
                            <li data-target="#carousel-1" data-slide-to="2"></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-light footer-basic">
        <footer class="text-dark footer">
            <div class="social"><img class="foot-lg" src="assets/img/logo.png"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
            <p class="copyright">Vishnu Silk &amp; Sarees © 2020</p>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>