<?php
session_start();
include('dbconn.php');
if(isset($_SESSION['client_id']))
{
    ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Vishnu Silk &amp; Sarees</title>
    <meta property="og:title" content="Vishnu silk &amp; Sarees">
    <meta property="og:type" content="website">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta property="og:image" content="assets/img/lg.jpg">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/android-chrome-512x512.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/mob.css">
    <link rel="stylesheet" href="assets/css/pc.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
</head>

<body>
    <div class="prof-mn-dv"><img class="about-lg" src="assets/img/logo.png">
        <div class="hf-circ-nxt">
            <div class="dropdown drp-dwn"><a class="thm-bg drp-dwn-btn" data-toggle="dropdown" aria-expanded="true"><i class="icon ion-chevron-down dropdown-icn"></i></a>
                <div class="jello animated dropdown-menu thm-bg thm-bg-mnu" role="menu"><a class="dropdown-item thm-bg-mnu-itm" href="index2.php" role="presentation"><i class="fas fa-home" style="color: #ab5959;"></i>&nbsp;Home</a><a class="dropdown-item thm-bg-mnu-itm" href="order.php" role="presentation"><i class="fas fa-shipping-fast" style="color: rgb(255,214,0);"></i>&nbsp;My Orders</a>
                    <a
                        class="dropdown-item thm-bg-mnu-itm" href="bid.php" role="presentation"><i class="fa fa-gavel" style="color: rgb(10,167,255);"></i>&nbsp; My Bid's</a><a class="dropdown-item thm-bg-mnu-itm" href="point.php" role="presentation"><i class="fa fa-diamond" style="color: rgb(255,0,168);"></i>&nbsp; Points</a>
                        <a
                            class="dropdown-item thm-bg-mnu-itm" href="about.php" role="presentation"><i class="fa fa-info-circle" style="color: rgb(255,153,0);"></i>&nbsp; About Us</a><a class="dropdown-item thm-bg-mnu-itm" role="presentation" data-toggle="modal" data-target="#alert-modal" href="contact.php"><i class="fa fa-phone" style="color: rgb(18,131,0);"></i>&nbsp; Contact Us</a></div>
            </div>
        </div>
    </div>
    <div class="article-list">
        <div class="container">
            <div class="intro">
                <h2 class="text-center">Head Office</h2>
                <p class="text-center"><span style="font-size: 20px;text-decoration: underline;"> Vishnu Silk & Sarees</span><br>Address. 365, Bhori Ali, Raviwar Peth ,<br> Pune.  411002</p>
            </div>
            <div class="row articles">
                <div class="col-sm-6 col-md-4 item"><a href="#"><img class="img-fluid" src="assets/img/desk.jpg"></a>
                    <h3 class="name">Contact Details</h3>
                    <p class="description">Shop : 020-24460786 / 24492786<br>
                    Phone : +91 9881439493</p><a class="action" href="#"><i class="fa fa-phone"></i></a></div>
                
            </div>
        </div>
    </div>
    <div class="article-list">
        <div class="container">
            <div class="intro">
                <h2 class="text-center">Brach No. 1</h2>
                <p class="text-center"><span style="font-size: 20px;text-decoration: underline;"> Vishnu Silk & Sarees</span><br>Address. 367, Bhori Ali, Raviwar Peth ,<br> Pune.  411002</p>
            </div>
            <div class="row articles">
                <div class="col-sm-6 col-md-4 item"><a href="#"><img class="img-fluid" src="assets/img/desk.jpg"></a>
                    <h3 class="name">Contact Details</h3>
                    <p class="description">Shop : 020-24479991 <br>
                    Phone : +91 9881439493</p><a class="action" href="#"><i class="fa fa-phone"></i></a></div>
                
            </div>
        </div>
    </div>
    <div class="article-list">
        <div class="container">
            <div class="intro">
                <h2 class="text-center">Branch No. 2</h2>
                <p class="text-center"><span style="font-size: 20px;text-decoration: underline;"> Vishnu Silk & Sarees</span><br>Address. Shop.No.1, Ashirwad Building, Near Dhayreshwar Mangal Karyalay. Dhayri Phata<br> Pune. 411041</p>
            </div>
            <div class="row articles">
                <div class="col-sm-6 col-md-4 item"><a href="#"><img class="img-fluid" src="assets/img/desk.jpg"></a>
                    <h3 class="name">Contact Details</h3>
                    <p class="description">Shop : 020-24460786 / 24492786<br>
                    Phone : +91 9881439493</p><a class="action" href="#"><i class="fa fa-phone"></i></a></div>
                
            </div>
        </div>
    </div>
    <!--
    <div class="team-boxed">
        <div class="container">
            <div class="intro">
                <h2 class="text-center">Team </h2>
                <p class="text-center">Nunc luctus in metus eget fringilla. Aliquam sed justo ligula. Vestibulum nibh erat, pellentesque ut laoreet vitae.</p>
            </div>
            <div class="row people">
                <div class="col-md-6 col-lg-4 item">
                    <div class="box"><img class="rounded-circle" src="assets/img/1.jpg">
                        <h3 class="name">Ben Johnson</h3>
                        <p class="title">Musician</p>
                        <p class="description">Aenean tortor est, vulputate quis leo in, vehicula rhoncus lacus. Praesent aliquam in tellus eu gravida. Aliquam varius finibus est, et interdum justo suscipit id. Etiam dictum feugiat tellus, a semper massa. </p>
                        <div class="social"><a href="#"><i class="fa fa-facebook-official"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 item">
                    <div class="box"><img class="rounded-circle" src="assets/img/2.jpg">
                        <h3 class="name">Emily Clark</h3>
                        <p class="title">Artist</p>
                        <p class="description">Aenean tortor est, vulputate quis leo in, vehicula rhoncus lacus. Praesent aliquam in tellus eu gravida. Aliquam varius finibus est, et interdum justo suscipit id. Etiam dictum feugiat tellus, a semper massa. </p>
                        <div class="social"><a href="#"><i class="fa fa-facebook-official"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 item">
                    <div class="box"><img class="rounded-circle" src="assets/img/3.jpg">
                        <h3 class="name">Carl Kent</h3>
                        <p class="title">Stylist</p>
                        <p class="description">Aenean tortor est, vulputate quis leo in, vehicula rhoncus lacus. Praesent aliquam in tellus eu gravida. Aliquam varius finibus est, et interdum justo suscipit id. Etiam dictum feugiat tellus, a semper massa. </p>
                        <div class="social"><a href="#"><i class="fa fa-facebook-official"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-instagram"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <div class="bg-light footer-basic">
        <footer class="text-dark footer">
            <div class="social"><img class="foot-lg" src="assets/img/logo.png"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
           <p class="copyright">© 2020 Vishnu Silk &amp; Sarees | Developed By - Softech Coders</p>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
<?php

}
else
{
    echo "failedddddd";
}
?>